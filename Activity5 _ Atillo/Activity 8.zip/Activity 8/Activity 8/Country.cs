﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity_8
{
    internal class Country
    {
        public string Name { get; set; }
        public string Capital { get; set; }
        public string Language { get; set; }

        public Country(string name, string capital, string language)
        {
            Name = name;
            Capital = capital;
            Language = language;
        }

        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Country  : {Name}");
            Console.WriteLine($"Capital  : {Capital}");
            Console.WriteLine($"Language : {Language}");
        }
    }

    // ================= DERIVED CLASS 1 =================
    class Japan : Country
    {
        public string PrimeMinister { get; set; }

        public Japan(string capital, string language, string primeMinister)
            : base("Japan", capital, language)
        {
            PrimeMinister = primeMinister;
        }

        public override void DisplayInfo()
        {
            Console.WriteLine("\n--- Japan Info ---");
            Console.WriteLine($"Prime Minister: {PrimeMinister}");
            base.DisplayInfo();
        }
    }

    // ================= DERIVED CLASS 2 =================
    class Philippines : Country
    {
        public string President { get; set; }

        public Philippines(string capital, string language, string president)
            : base("Philippines", capital, language)
        {
            President = president;
        }

        public override void DisplayInfo()
        {
            Console.WriteLine("\n--- Philippines Info ---");
            Console.WriteLine($"President: {President}");
            base.DisplayInfo();
        }
    }
}
