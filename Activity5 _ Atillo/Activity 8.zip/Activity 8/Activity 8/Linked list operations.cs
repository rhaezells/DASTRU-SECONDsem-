﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity_8
{
    internal class Linked_list_operations
    {
        private LinkedList<Country> countries = new LinkedList<Country>();

        public void Insert(Country country)
        {
            countries.AddLast(country);
            Console.WriteLine("Country added successfully!\n");
        }

        public void Remove(string name)
        {
            var node = countries.First;

            while (node != null)
            {
                if (node.Value.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    countries.Remove(node);
                    Console.WriteLine("Country removed successfully!\n");
                    return;
                }
                node = node.Next;
            }

            Console.WriteLine("Country not found.\n");
        }

        public void Display()
        {
            if (countries.Count == 0)
            {
                Console.WriteLine("List is empty.\n");
                return;
            }

            foreach (var country in countries)
            {
                country.DisplayInfo();
            }
        }
        }
}
