﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity_8
{
    internal static class UserInput
    {
        public static string GetString(string message)
        {
            while (true)
            {
                try
                {
                    Console.Write(message);
                    string input = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(input))
                        throw new Exception("Input cannot be empty.");

                    return input;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }

        public static int GetInt(string message)
        {
            while (true)
            {
                try
                {
                    Console.Write(message);
                    return Convert.ToInt32(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Invalid number. Please try again.");
                }
            }
        }
    }
}
