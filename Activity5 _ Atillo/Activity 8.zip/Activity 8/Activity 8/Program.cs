﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Name: John RHaezel C. Atillo
            //Section: IT401P
            //Title Activity: ACTIVITY 8:  Linked List in OOP
            Linked_list_operations list = new Linked_list_operations();
            bool exit = false;

            while (!exit)
            {
               
                Console.WriteLine("\n===== MENU =====");
                Console.WriteLine("1. Insert Country");
                Console.WriteLine("2. Remove Country");
                Console.WriteLine("3. Display Countries");
                Console.WriteLine("4. Exit");

                int choice = UserInput.GetInt("Choose option: ");
                
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("\n1. Japan");
                        Console.WriteLine("2. Philippines");
                        int type = UserInput.GetInt("Select country type: ");

                        if (type == 1)
                        {
                            string capital = UserInput.GetString("Enter Capital: ");
                            string language = UserInput.GetString("Enter Language: ");
                            string pm = UserInput.GetString("Enter Prime Minister: ");

                            list.Insert(new Japan(capital, language, pm));
                        }
                        else if (type == 2)
                        {
                            string capital = UserInput.GetString("Enter Capital: ");
                            string language = UserInput.GetString("Enter Language: ");
                            string president = UserInput.GetString("Enter President: ");

                            list.Insert(new Philippines(capital, language, president));
                        }
                        else
                        {
                            Console.WriteLine("Invalid selection.");
                        }
                        break;

                    case 2:
                        string name = UserInput.GetString("Enter country name to remove: ");
                        list.Remove(name);
                        break;

                    case 3:
                        list.Display();
                        break;

                    case 4:
                        exit = true;
                        break;

                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
        }
    }
}
